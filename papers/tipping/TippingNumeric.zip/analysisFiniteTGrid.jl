## n: number of gridpoints
## Dmax: endpoints of equally spaced grid are -Dmax and Dmax

using PyPlot#: plot, subplots, savefig, set_xlabel, set_ylabel
using LaTeXStrings

#per period payoff of 1 given qualities and own investment i
function D1(Delta::Float64)
    temp = (1.0+Delta)/2
    if temp<0.0
        return 0.0
    elseif temp>1.0
        return 1.0
    else
        return temp
    end
end

function D2(Delta::Float64)
    temp = (1.0-Delta)/2
    if temp<0.0
        return 0.0
    elseif temp>1.0
        return 1.0
    else
        return temp
    end
end

#costs of investment i given previous period demand D
function c(i::Float64,D::Float64,gam::Float64=1.0,alpha::Float64=0.5)
    gam*i*i/2.0+alpha*(1.0-D)*i
end

#per period payoff of firm 1 when investing i and previous period quality difference was Delta 
function u1(Delta::Float64,i::Float64,gam::Float64=1.0,alpha::Float64=0.5)
    return D1(Delta+i)-c(i,D1(Delta),gam,alpha)
end

function u2(Delta::Float64,i::Float64,gam::Float64=1.0,alpha::Float64=0.5)
    return D2(Delta-i)-c(i,D2(Delta),gam,alpha)
end

#type "backwards induction equilibrium" that contains values function and optimal policy for T period game
type bieq
    V1::Array{Float64,2} #value of firm 1, n by T where n is number of grid points and T is number of periods
    V2::Array{Float64,2}
    i1::Array{Int64,2} #investment of firm 1 in grid points
    i2::Array{Int64,2}
end

#note Delta grids will be ordered starting with negative values

bieq(n::Int64,T::Int64) = bieq(zeros(n,T),zeros(n,T),zeros(Int64,n,T),zeros(Int64,n,T))

function buildEdge(n::Int64,Dmax::Float64,T::Int64,gam::Float64,alpha::Float64)
    grid = linspace(-Dmax,Dmax,n)
    eq = bieq(n,T)
    if iseven(T)#firm 2's turn to invest in T
        for j in 1:n
            options = Float64[u2(grid[j],grid[j]-grid[i],gam,alpha) for i in 1:j]
            Vopt,jopt = findmax(options)
            eq.V1[j,T] = u1(grid[jopt],0.0,gam,alpha)
            eq.V2[j,T] = Vopt
            eq.i2[j,T] = j-jopt
        end
    else # firm 1's turn to invest in T
        for j in 1:n
            options = Float64[u1(grid[j],grid[i]-grid[j],gam,alpha) for i in j:n]
            Vopt,jopt = findmax(options)
            eq.V1[j,T] = Vopt
            eq.V2[j,T] = u2(grid[jopt+j-1],0.0,gam,alpha)
            eq.i1[j,T] = jopt-1
        end
    end
    return eq
end



function buildEq(n::Int64,Dmax::Float64,T::Int64,gam::Float64,alpha::Float64,delta::Float64)
    eq = buildEdge(n,Dmax,T,gam,alpha)
    grid = linspace(-Dmax,Dmax,n)
    for t in T-1:-1:1
        if iseven(t)#firm 2's turn to invest in T
            for j in 1:n
                options = Float64[u2(grid[j],grid[j]-grid[i],gam,alpha)+delta*eq.V2[i,t+1] for i in 1:j]
                Vopt,jopt = findmax(options)
                eq.V1[j,t] = u1(grid[jopt],0.0,gam,alpha)
                eq.V2[j,t] = Vopt
                eq.i2[j,t] = j-jopt
            end
        else # firm 1's turn to invest in T
            for j in 1:n
                options = Float64[u1(grid[j],grid[i]-grid[j],gam,alpha)+delta*eq.V1[i,t+1] for i in j:n]
                Vopt,jopt = findmax(options)
                eq.V1[j,t] = Vopt
                eq.V2[j,t] = u2(grid[jopt+j-1],0.0,gam,alpha)
                eq.i1[j,t] = jopt-1
            end
        end
    end
    return eq
end

#for a given initial quality difference gives the path of quality differences (all Deltas are (changes in) grid point positions and therefore Integer)
function DeltaPath(Delta0::Int64,n::Int64,Dmax::Float64,T::Int64,gam::Float64,alpha::Float64,delta::Float64)
    Deltas = Vector{Int64}(T)
    inv1 = Vector{Int64}(Int(ceil(T/2)))
    inv2 = Vector{Int64}(Int(floor(T/2)))
    eq = buildEq(n,Dmax,T,gam,alpha,delta)
    Deltas[1] = Delta0+eq.i1[Delta0,1]
    inv1[1] = eq.i1[Delta0,1]
    for t in 2:T
        if iseven(t)
            Deltas[t] = Deltas[t-1] - eq.i2[Deltas[t-1],t]
            inv2[Int(t/2)] = eq.i2[Deltas[t-1],t]
        else
            Deltas[t] = Deltas[t-1] + eq.i1[Deltas[t-1],t]
            inv1[Int((t+1)/2)] = eq.i1[Deltas[t-1],t]
        end
    end
    return Deltas, inv1, inv2
end

function plotDeltaInv(Delta0::Int64,n::Int64,Dmax::Float64,T::Int64,gam::Float64,alpha::Float64,delta::Float64,filename::String)
    Deltas, inv1, inv2 = DeltaPath(Delta0,n,Dmax,T,gam,alpha,delta) #returns are in Int, i.e. gridpoint
    Deltas = (Deltas.-n/2).*(2*Dmax/n) #convert to quality units
    prepend!(Deltas,[(Delta0-n/2)*2*Dmax/n]) #add initial quality level
    inv1 = inv1.*(2*Dmax/n) #convert to quality units
    inv2 = inv2.*(2*Dmax/n)
    fig, ax = subplots()
    ax[:plot](0:1:T, Deltas, "b-", linewidth=1.5, label=string(L"$\Delta_t$"), alpha=0.6)              
    ax[:set_ylabel](L"$x_{i,t},\,\Delta_t$",fontsize="20")
    ax[:set_xlabel](L"$t$",fontsize="20")
    ax[:plot](1:2:T,inv1,"r.", linewidth=2,label=string(L"$x_{1,t}$"))
    ax[:plot](2:2:T,inv2,"g*", linewidth=2,label=string(L"$x_{2,t}$"))
    ax[:legend](loc="center right",fontsize="20")
    savefig(filename)
    return fig
end
              
plotDeltaInv(200,400,2.0,30,1.0,0.4,0.0,"wiggle.pdf")
plotDeltaInv(200,400,2.0,30,1.0,0.4,0.25,"tipped.pdf")
