type equilibrium
    V11::Array{Float64,2} #Matrix of size n,n; value function of firm 1 when 1 can invest
    V12::Array{Float64,2} # value function of firm 1 when 2 can invest
    V21::Array{Float64,2}
    V22::Array{Float64,2}
    i1::Array{Int64,2} # investment of firm 1 in grid points
    i2::Array{Int64,2}
end



#= remarks on the grid: Taking the same  n point quality grid for both firms, Tau=2n-1 and class tau has min(tau,2n-tau) nodes (directed component only). Within class tau, each node (d1,d2) is such that d1+d2=tau+1 and d1=max(tau-n+1,1)...min(tau,n)  =#

#builds the continuation equilibria along the edges, i.e. when one firm has maximum quality already
function edges(n::Int64,qmax::Float64=10.0,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5)
    grid = linspace(0.0,qmax,n)
    eqStart = equilibrium(zeros(n,n),zeros(n,n),zeros(n,n),zeros(n,n),zeros(Int64,n,n),zeros(Int64,n,n))
    qmax = grid[n]
    eqStart.V11[n,n] = u1(qmax,qmax,0.0,gam,alpha)/(1-delta)
    eqStart.V22[n,n] = u2(qmax,qmax,0.0,gam,alpha)/(1-delta)
    eqStart.V12[n,n] = u1(qmax,qmax,0.0,gam,alpha)/(1-delta)
    eqStart.V21[n,n] = u2(qmax,qmax,0.0,gam,alpha)/(1-delta)
    eqList = [eqStart] #list of all continuation equilibria
    for d1 in n-1:-1:1
        newEqList = Array(equilibrium,0)
        q1 = grid[d1] #current quality firm 1
        for eq in eqList
            options =  vcat([u1(q1,qmax,0.0,gam,alpha)/(1-delta)],[u1(q1,qmax,grid[d1i]-q1,gam,alpha)+delta*eq.V12[d1i,n] for d1i in d1+1:n]) #current payoff plus discounted continuation values of firm 1 for all possible investment levels
            maxV = maximum(options) #gives Value
            maxK = find(x-> x==maxV,options) #gives indices of all maxima
            for max in maxK #in case there are several optimal choices, we loop through all
                V11new = copy(eq.V11)
                V11new[d1,n] = maxV
                V12new = copy(eq.V12)
                V12new[d1,n] = u1(q1,qmax,0.0,gam,alpha)+delta*maxV
                V21new = copy(eq.V21)
                V22new = copy(eq.V22)
                if max==1
                    V21new[d1,n] = u2(q1,qmax,0.0,gam,alpha)/(1-delta)
                    V22new[d1,n] = u2(q1,qmax,0.0,gam,alpha)/(1-delta)
                else
                    V21new[d1,n] = u2(grid[d1+max-1],qmax,0.0,gam,alpha)+delta*V22new[d1+max-1,n]
                    V22new[d1,n] = u2(q1,qmax,0.0,gam,alpha)+delta*V21new[d1,n]
                end
                i1new = copy(eq.i1)
                i1new[d1,n] = max-1
                push!(newEqList,equilibrium(V11new,V12new,V21new,V22new,i1new,eq.i2)) #add new continuation equilibrium to newEqList
            end
        end
        eqList = newEqList
    end
    for d2 in n-1:-1:1
        newEqList = Array(equilibrium,0)
        q2 = grid[d2] #current quality firm 1
        for eq in eqList
            options =  vcat([u2(qmax,q2,0.0,gam,alpha)/(1-delta)],[u2(qmax,q2,grid[d2i]-q2,gam,alpha)+delta*eq.V21[n,d2i] for d2i in d2+1:n]) #current payoff plus discounted continuation values of firm 1 for all possible investment levels
            maxV = maximum(options) #gives Value
            maxK = find(x-> x==maxV,options) #gives indices of all maxima
            for max in maxK #in case there are several optimal choices, we loop through all
                V22new = copy(eq.V22)
                V22new[n,d2] = maxV
                V21new = copy(eq.V21)
                V21new[n,d2] =u2(qmax,q2,0.0,gam,alpha) + delta*maxV
                V12new = copy(eq.V12)
                V11new = copy(eq.V11)
                if max==1
                    V12new[n,d2] = u1(qmax,q2,0.0,gam,alpha)/(1-delta)
                    V11new[n,d2] = u1(qmax,q2,0.0,gam,alpha)/(1-delta)
                else
                    V12new[n,d2] = u1(qmax,grid[d2+max-1],0.0,gam,alpha)+delta*eq.V11[n,d2+max-1]
                    V11new[n,d2] = u1(qmax,q2,0.0,gam,alpha)+delta*V12new[n,d2]
                end
                i2new = copy(eq.i2)
                i2new[n,d2] = max-1
                push!(newEqList,equilibrium(V11new,V12new,V21new,V22new,eq.i1,i2new)) #add new continuation equilibrium to newEqList
            end
        end
        eqList = newEqList
    end
    return eqList
end 

#calculates all pure strategy equilibria of the alternating move game; returns a list of equilibria
function findAllEq(n::Int64,qmax::Float64=10.0,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5)
    grid = linspace(0.0,qmax,n)
    eqList = edges(n,qmax,delta,gam,alpha)
    for tau in 2*n-3:-1:1 #not the same tau as in the paper: my first (last) stage is 2n-1 (1); note that two stages are done in "edges" hence I start at 2n-3 and not at 2n-1
        #println("tau is ",tau)
        for d1 in max(tau-n+1+1,1):min(tau,n-1) #+1 and -1 beacause edges are already taken care of; here is a problem: d1 is of type Core.Box
            d2 = tau+1-d1
            noEq = 1 #flag that is turned 0 if a continuation equilibrium is found
            #first say firm 1 is abe to invest in (d1,d2)
            newEqList = Array(equilibrium,0) #list of all continuation equilibria
            q1 = grid[d1] #current quality firm 1
            q2 = grid[d2]
            for eq in eqList
                options1P =  Float64[u1(q1,q2,grid[d1i]-q1,gam,alpha)+delta*eq.V12[d1i,d2] for d1i in d1+1:n] #current payoff plus discounted continuation values of firm 1 for all possible strictly positive investment levels; the "Float64" is necessary to get type inference to work
                maxV1P = maximum(options1P) #gives Value
                maxK1P = find(x-> x==maxV1P,options1P) #gives indices of all maxima
                options2P =  Float64[u2(q1,q2,grid[d2i]-q2,gam,alpha)+delta*eq.V21[d1,d2i] for d2i in d2+1:n]
                maxV2P = maximum(options2P) #gives Value
                maxK2P = find(x-> x==maxV2P,options2P) #gives indices of all maxima
                #println(length(maxK1P)," ",length(maxK2P))
                for max1P in maxK1P #in case there are several optimal choices, we loop through all
                    for max2P in maxK2P
                        v21P = u2(grid[d1+max1P],q2,0.0,gam,alpha)+delta*eq.V22[d1+max1P,d2] #value of firm 2 if firm 1 chooses a strictly positive investment max1P
                        v12P = u1(q1,grid[d2+max2P],0.0,gam,alpha)+delta*eq.V11[d1,d2+max2P]
                        if maxV1P >= u1(q1,q2,0.0,gam,alpha)+delta*v12P && maxV2P >= u2(q1,q2,0.0,gam,alpha) + delta*v21P #positive invest better than 0 invest for both
                            V11new = copy(eq.V11)
                            V11new[d1,d2] = maxV1P
                            V21new = copy(eq.V21)
                            V21new[d1,d2] = v21P
                            V22new = copy(eq.V22)
                            V22new[d1,d2] = maxV2P
                            V12new = copy(eq.V12)
                            V12new[d1,d2] = v12P
                            i1new = copy(eq.i1)
                            i1new[d1,d2] = max1P
                            i2new = copy(eq.i2)
                            i2new[d1,d2] = max2P
                            push!(newEqList,equilibrium(V11new,V12new,V21new,V22new,i1new,i2new)) #add new continuation equilibrium to newEqList
                            noEq = 0
                        end
                        if maxV1P <= u1(q1,q2,0.0,gam,alpha)+delta*v12P && maxV2P >= u2(q1,q2,0.0,gam,alpha)/(1-delta)# firm 1 does not invest but firm 2 does
                            V11new = copy(eq.V11)
                            V11new[d1,d2] = u1(q1,q2,0.0,gam,alpha)+delta*v12P
                            V21new = copy(eq.V21)
                            V21new[d1,d2] = u2(q1,q2,0.0,gam,alpha)+delta*maxV2P
                            V22new = copy(eq.V22)
                            V22new[d1,d2] = maxV2P
                            V12new = copy(eq.V12)
                            V12new[d1,d2] = v12P
                            i1new = copy(eq.i1)
                            i1new[d1,d2] = 0
                            i2new = copy(eq.i2)
                            i2new[d1,d2] = max2P
                            push!(newEqList,equilibrium(V11new,V12new,V21new,V22new,i1new,i2new))
                            noEq = 0
                        end                        
                        if maxV1P >= u1(q1,q2,0.0,gam,alpha)/(1-delta) && maxV2P <= u2(q1,q2,0.0,gam,alpha) + delta*v21P #firm 1 invests positve amount firm 2 does not
                            V11new = copy(eq.V11)
                            V11new[d1,d2] = maxV1P
                            V21new = copy(eq.V21)
                            V21new[d1,d2] = v21P
                            V22new = copy(eq.V22)
                            V22new[d1,d2] = u2(q1,q2,0.0,gam,alpha)+delta*v21P
                            V12new = copy(eq.V12)
                            V12new[d1,d2] = u1(q1,q2,0.0,gam,alpha)+delta*maxV1P
                            i1new = copy(eq.i1)
                            i1new[d1,d2] = max1P
                            i2new = copy(eq.i2)
                            i2new[d1,d2] = 0
                            push!(newEqList,equilibrium(V11new,V12new,V21new,V22new,i1new,i2new))
                            noEq = 0
                        end                        
                        if u1(q1,q2,0.0,gam,alpha)/(1-delta)>= maxV1P && u2(q1,q2,0.0,gam,alpha)/(1-delta)>=maxV2P  #neither firm invests
                            V11new = copy(eq.V11)
                            V11new[d1,d2] = u1(q1,q2,0.0,gam,alpha)/(1-delta)
                            V21new = copy(eq.V21)
                            V21new[d1,d2] = u2(q1,q2,0.0,gam,alpha)/(1-delta)
                            V22new = copy(eq.V22)
                            V22new[d1,d2] = u2(q1,q2,0.0,gam,alpha)/(1-delta)
                            V12new = copy(eq.V12)
                            V12new[d1,d2] = u1(q1,q2,0.0,gam,alpha)/(1-delta)
                            i1new = copy(eq.i1)
                            i1new[d1,d2] = 0
                            i2new = copy(eq.i2)
                            i2new[d1,d2] = 0
                            push!(newEqList,equilibrium(V11new,V12new,V21new,V22new,i1new,i2new))
                            noEq = 0                      
                        end
                    end
                end
end
            if noEq==1
                error("no pure strategy equilibrium exists")
            end
            eqList = newEqList
        end
    end
    return eqList
end

#findEq(3,0.75,1.0,1.0) #simple example where  there are multiple equilibria and I checked the first two equilibria by hand for n=3 and grid [0.0,0.5,1.0]

#calculates one pure strategy equilibrium of the alternating move game where whenever possible firms invest
function findInvestEq(n::Int64,qmax::Float64=10.0,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5)
    grid = linspace(0.0,qmax,n)
    eq = edges(n,qmax,delta,gam,alpha)[1]
    for tau in 2*n-3:-1:1 #not the same tau as in the paper: my first (last) stage is 2n-1 (1); note that two stages are done in "edges" hence I start at 2n-3 and not at 2n-1
        #println("tau is ",tau)
        for d1 in max(tau-n+1+1,1):min(tau,n-1) #+1 and -1 beacause edges are already taken care of; here is a problem: d1 is of type Core.Box
            d2 = tau+1-d1
            noEq = true #flag that is turned 0 if a continuation equilibrium is found
            #first say firm 1 is abe to invest in (d1,d2)
            #newEqList = Array(equilibrium,0) #list of all continuation equilibria
            q1 = grid[d1] #current quality firm 1
            q2 = grid[d2]
            options1P =  Float64[u1(q1,q2,grid[d1i]-q1,gam,alpha)+delta*eq.V12[d1i,d2] for d1i in d1+1:n] #current payoff plus discounted continuation values of firm 1 for all possible strictly positive investment levels; the "Float64" is necessary to get type inference to work
            maxV1P, max1P = findmax(options1P)
            options2P =  Float64[u2(q1,q2,grid[d2i]-q2,gam,alpha)+delta*eq.V21[d1,d2i] for d2i in d2+1:n]
            maxV2P,max2P = findmax(options2P)
            v21P = u2(grid[d1+max1P],q2,0.0,gam,alpha)+delta*eq.V22[d1+max1P,d2] #value of firm 2 if firm 1 chooses a strictly positive investment max1P
            v12P = u1(q1,grid[d2+max2P],0.0,gam,alpha)+delta*eq.V11[d1,d2+max2P]
            if maxV1P >= u1(q1,q2,0.0,gam,alpha)+delta*v12P && maxV2P >= u2(q1,q2,0.0,gam,alpha) + delta*v21P #positive invest better than 0 invest for both
                eq.V11[d1,d2] = maxV1P
                eq.V21[d1,d2] = v21P
                eq.V22[d1,d2] = maxV2P
                eq.V12[d1,d2] = v12P
                eq.i1[d1,d2] = max1P
                eq.i2[d1,d2] = max2P
                noEq = false
            elseif maxV1P <= u1(q1,q2,0.0,gam,alpha)+delta*v12P && maxV2P >= u2(q1,q2,0.0,gam,alpha)/(1-delta)# firm 1 does not invest but firm 2 does
                eq.V11[d1,d2] = u1(q1,q2,0.0,gam,alpha)+delta*v12P
                eq.V21[d1,d2] = u2(q1,q2,0.0,gam,alpha)+delta*maxV2P
                eq.V22[d1,d2] = maxV2P
                eq.V12[d1,d2] = v12P
                eq.i1[d1,d2] = 0
                eq.i2[d1,d2] = max2P
                noEq = false
            elseif maxV1P >= u1(q1,q2,0.0,gam,alpha)/(1-delta) && maxV2P <= u2(q1,q2,0.0,gam,alpha) + delta*v21P #firm 1 invests positve amount firm 2 does not
                eq.V11[d1,d2] = maxV1P
                eq.V21[d1,d2] = v21P
                eq.V22[d1,d2] = u2(q1,q2,0.0,gam,alpha)+delta*v21P
                eq.V12[d1,d2] = u1(q1,q2,0.0,gam,alpha)+delta*maxV1P
                eq.i1[d1,d2] = max1P
                eq.i2[d1,d2] = 0
                noEq = false
            elseif u1(q1,q2,0.0,gam,alpha)/(1-delta)>= maxV1P && u2(q1,q2,0.0,gam,alpha)/(1-delta)>=maxV2P  #neither firm invests
                eq.V11[d1,d2] = u1(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.V21[d1,d2] = u2(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.V22[d1,d2] = u2(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.V12[d1,d2] = u1(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.i1[d1,d2] = 0
                eq.i2[d1,d2] = 0
                noEq = false                     
            end
            if noEq==true
                error("no pure strategy equilibrium exists")
            end
        end
    end
    return eq
end

#calculates one pure strategy equilibrium of the alternating move game where whenever possible a steady state is chosen as continuation equilibrium
function findSSEq(n::Int64,qmax::Float64=10.0,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5)
    grid = linspace(0.0,qmax,n)
    eq = edges(n,qmax,delta,gam,alpha)[1]
    for tau in 2*n-3:-1:1 #not the same tau as in the paper: my first (last) stage is 2n-1 (1); note that two stages are done in "edges" hence I start at 2n-3 and not at 2n-1
        #println("tau is ",tau)
        for d1 in max(tau-n+1+1,1):min(tau,n-1) #+1 and -1 beacause edges are already taken care of; here is a problem: d1 is of type Core.Box
            d2 = tau+1-d1
            noEq = true #flag that is turned 0 if a continuation equilibrium is found
            #first say firm 1 is abe to invest in (d1,d2)
            #newEqList = Array(equilibrium,0) #list of all continuation equilibria
            q1 = grid[d1] #current quality firm 1
            q2 = grid[d2]
            options1P =  Float64[u1(q1,q2,grid[d1i]-q1,gam,alpha)+delta*eq.V12[d1i,d2] for d1i in d1+1:n] #current payoff plus discounted continuation values of firm 1 for all possible strictly positive investment levels; the "Float64" is necessary to get type inference to work
            maxV1P, max1P = findmax(options1P)
            options2P =  Float64[u2(q1,q2,grid[d2i]-q2,gam,alpha)+delta*eq.V21[d1,d2i] for d2i in d2+1:n]
            maxV2P,max2P = findmax(options2P)
            v21P = u2(grid[d1+max1P],q2,0.0,gam,alpha)+delta*eq.V22[d1+max1P,d2] #value of firm 2 if firm 1 chooses a strictly positive investment max1P
            v12P = u1(q1,grid[d2+max2P],0.0,gam,alpha)+delta*eq.V11[d1,d2+max2P]
            if u1(q1,q2,0.0,gam,alpha)/(1-delta)>= maxV1P && u2(q1,q2,0.0,gam,alpha)/(1-delta)>=maxV2P  #neither firm invests
                eq.V11[d1,d2] = u1(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.V21[d1,d2] = u2(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.V22[d1,d2] = u2(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.V12[d1,d2] = u1(q1,q2,0.0,gam,alpha)/(1-delta)
                eq.i1[d1,d2] = 0
                eq.i2[d1,d2] = 0
                noEq = false
            elseif maxV1P <= u1(q1,q2,0.0,gam,alpha)+delta*v12P && maxV2P >= u2(q1,q2,0.0,gam,alpha)/(1-delta)# firm 1 does not invest but firm 2 does
                eq.V11[d1,d2] = u1(q1,q2,0.0,gam,alpha)+delta*v12P
                eq.V21[d1,d2] = u2(q1,q2,0.0,gam,alpha)+delta*maxV2P
                eq.V22[d1,d2] = maxV2P
                eq.V12[d1,d2] = v12P
                eq.i1[d1,d2] = 0
                eq.i2[d1,d2] = max2P
                noEq = false
            elseif maxV1P >= u1(q1,q2,0.0,gam,alpha)/(1-delta) && maxV2P <= u2(q1,q2,0.0,gam,alpha) + delta*v21P #firm 1 invests positive amount firm 2 does not
                eq.V11[d1,d2] = maxV1P
                eq.V21[d1,d2] = v21P
                eq.V22[d1,d2] = u2(q1,q2,0.0,gam,alpha)+delta*v21P
                eq.V12[d1,d2] = u1(q1,q2,0.0,gam,alpha)+delta*maxV1P
                eq.i1[d1,d2] = max1P
                eq.i2[d1,d2] = 0
                noEq = false
            elseif maxV1P >= u1(q1,q2,0.0,gam,alpha)+delta*v12P && maxV2P >= u2(q1,q2,0.0,gam,alpha) + delta*v21P #positive invest better than 0 invest for both
                eq.V11[d1,d2] = maxV1P
                eq.V21[d1,d2] = v21P
                eq.V22[d1,d2] = maxV2P
                eq.V12[d1,d2] = v12P
                eq.i1[d1,d2] = max1P
                eq.i2[d1,d2] = max2P
                noEq = false                     
            end
            if noEq==true
                error("no pure strategy equilibrium exists")
            end
        end
    end
    return eq
end

#note for the following that the maximum number of periods before reaching a steady state is 4*n, i.e. it is enough to consider 2n possibilities for both firms to invest

#fixing initial quality of firm 2 at 0 (by default), shows to which steady state quality difference the system converges for different initial quality levels of q1
function finalSteadyState(n::Int64,qmax::Float64=10.0,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5,d2::Int64=1,eqCalc::Function=findInvestEq)
    grid = linspace(0.0,qmax,n)
    eq = eqCalc(n,qmax,delta,gam,alpha)
    finalDelta = zeros(n)
    finalD1 = zeros(Int,n)
    finalD2 = zeros(Int,n)
    for d1 in 1:n
        d1t = d1
        d2t = d2
        for t in 1:2*n-d1
            d1t = d1t + eq.i1[d1t,d2t]
            d2t = d2t + eq.i2[d1t,d2t]
        end
        finalD1[d1] = d1t
        finalD2[d1] = d2t
        finalDelta[d1] = grid[d1t]-grid[d2t]
    end
    return finalDelta,finalD1,finalD2
end
