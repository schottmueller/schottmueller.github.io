#= convention variable names:
gam::Float64 gamma parameter in cost function
alpha::Float64 alpha parameter in cost function
i is investment either in gridpoints (then Int64) or (only in cost, utility function) in amount (Float64)
q1::Float64 is quality firm 1
q2::Float64 is quality firm 2
x::Int64 is the firm allowed to invest (1 or 2)
D::Float64 is demand (previous period)
delta::Float64 discount factor=#

#per period payoff of 1 given qualities and own investment i
function D1(q1::Float64,q2::Float64)
    temp = (1.0+q1-q2)/2
    if temp<0.0
        return 0.0
    elseif temp>1.0
        return 1.0
    else
        return temp
    end
end

function D2(q1::Float64,q2::Float64)
    temp = (1.0+q2-q1)/2
    if temp<0.0
        return 0.0
    elseif temp>1.0
        return 1.0
    else
        return temp
    end
end

#costs of investment i given previous period demand D
function c(i::Float64,D::Float64,gam::Float64=1.0,alpha::Float64=0.5)
    gam*i*i/2.0+alpha*(1.0-D)*i
end

#per period payoff of firm 1  
function u1(q1::Float64,q2::Float64,i::Float64,gam::Float64=1.0,alpha::Float64=0.5)
    return D1(q1+i,q2)-c(i,D1(q1,q2),gam,alpha)
end

function u2(q1::Float64,q2::Float64,i::Float64,gam::Float64=1.0,alpha::Float64=0.5)
    return D2(q1,q2+i)-c(i,D2(q1,q2),gam,alpha)
end

