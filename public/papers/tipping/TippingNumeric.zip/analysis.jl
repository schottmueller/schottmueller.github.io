#include file with model primitives, e.g. utility and cost functions
include("primitives.jl")
#include file that has all the solution algorithms 
include("DDG.jl")


using PyPlot#: plot, subplots, savefig, set_xlabel, set_ylabel
using LaTeXStrings


#plots the quality difference Delta to which play converges for different values of intial quality of firm 1
function plotDeltaFinalSS(n::Int64,qmax::Float64=10.0,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5,d2::Int64=1,eqCalc::Function=findInvestEq,filename::String="DeltaGraph.pdf")
    Delta = finalSteadyState(n,qmax,delta,gam,alpha,d2,eqCalc)[1]
    fig, ax = subplots()
    ax[:plot](linspace(0.0,qmax,n), Delta, "b.", linewidth=2, label=string(L"Eventual steady state $\Delta$, given $q_{2,0}=$",round((d2-1)*qmax/(n-1),1)), alpha=0.6)
    ax[:legend](loc="lower right")
    ax[:set_ylabel](L"$\Delta$")
    ax[:set_xlabel](L"$q_{1,0}$")
    ax[:plot]([0.0, qmax],[1.0,1.0],"--",color="gray", linewidth=0.5)
    ax[:plot]([0.0, qmax],[-1.0,-1.0],"--",color="gray", linewidth=0.5)
    savefig(filename)
    return fig
end



#getting Vectors of (for initial starting qualities) returns a Vector that is 0 if both firms end up with maximal quality, 1 if there is an interior steady state, 2 (3) if the market tips in favor of firm 1 (2)
function codeOutcome(n::Int64,qmax::Float64,q1end::Array{Int64,1},q2end::Array{Int64,1})
    m = length(q1end)
    out = ones(Int64,m)
    for i in 1:m
        if q1end[i]==q2end[i]==n
            out[i] = 0     
        elseif q1end[i]-q2end[i]>=floor(n/qmax)
            out[i] = 2
        elseif q2end[i]-q1end[i]>=floor(n/qmax) 
            out[i] = 3
        end
    end
    return out
end

            
#returns the outcome for the given ranges coded as in codeOutcome; step is used to skip some initial quality levels
function tippingStats(n::Int64,qmax::Float64,step::Int64=1,deltarange::Array{Float64,1}=[i for i in 0.0:0.3:0.9],gammarange::Array{Float64,1}=[1.0],alpharange::Array{Float64,1}=[i for i in 0.5:0.25:1.0],coding::Bool=true,d2::Int64=1)
    D,G,A = length(deltarange),length(gammarange),length(alpharange)
    k = length(1:step:n)
    if coding ==true
        outI = Array(Int64,k,D,G,A)
        outSS = Array(Int64,k,D,G,A)
    else
        outI = Array(Tuple{Array{Int64,1},Array{Int64,1}},k,D,G,A)
        outSS = Array(Tuple{Array{Int64,1},Array{Int64,1}},k,D,G,A)
    end
    for d in 1:D
        for g in 1:G
            for a in 1:A
                DeltaI,q1I,q2I = finalSteadyState(n,qmax,deltarange[d],gammarange[g],alpharange[a],d2,findInvestEq)
                DeltaSS,q1SS,q2SS = finalSteadyState(n,qmax,deltarange[d],gammarange[g],alpharange[a],d2,findSSEq)
                if coding == true
                    outI[1:k,d,g,a] = codeOutcome(n,qmax,q1I[1:step:end],q2I[1:step:end])
                    outSS[1:k,d,g,a] = codeOutcome(n,qmax,q1SS[1:step:end],q2SS[1:step:end])
                else
                    outI[1:k,d,g,a] = q1I[1:step:end],q2I[1:step:end]
                    outSS[1:k,d,g,a] = q1SS[1:step:end],q2SS[1:step:end]
                end               
            end
        end
    end
    return outI, outSS
end

#prints a LaTeX-code like table of long run behavior of the market for a range of alpha values in the Invest and the SS equilibrium
function maketable(alpharange::Array{Float64,1},n::Int=501,qmax::Float64=10.0,step::Int=50,d2::Int=250)
    dataI,dataSS = tippingStats(n,qmax,step,[0.75],[1.0],alpharange,true,d2)
    dict = Dict(0=>"MaxQ",1=>"IntQ",2=>"tip1",3=>"tip2")
    firstrow = string("\$\\alpha\$    ")
    for j in 1:length(1:step:n)
        firstrow = firstrow*string("\&","\$q_{1,0}=",round(((j-1)*step*qmax)/n,1),"\$")
    end
    firstrow = firstrow *"\\"*"\\"
    println(firstrow)
    #dataI
    println("Invest Equilibrium")
    for (ai,alpha) in enumerate(alpharange)
        row = string("\$\\alpha=",alpha,"\$")
        for j in 1:length(1:step:n)
            row = row*" "*"\&"*" "*dict[dataI[j,1,1,ai]]
        end
        row = row*"\\"*"\\"
        println(row)
    end
    #dataSS
    println("Steady State Equilibrium")
    for (ai,alpha) in enumerate(alpharange)
        row = string("\$\\alpha=",alpha,"\$")
        for j in 1:length(1:step:n)
            row = row*" "*"\&"*" "*dict[dataSS[j,1,1,ai]]
        end
        row = row*"\\"*"\\"
        println(row)
    end
    return true
end

#gives number of pure equilibria for different values of n keeping qmax fix
function noEq(nrange::Array{Int,1},qmax::Float64=10.0,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5)
    out = zeros(Int64,length(nrange))
    for i in 1:length(nrange)
        out[i] = length(findAllEq(nrange[i],qmax,delta,gam,alpha))
    end
    return out'
end

#gives number of pure equilibria for different values of n keeping spacing between grid points fix
function noEqEqualSpace(nrange::Array{Int,1},space::Float64=0.25,delta::Float64=0.9,gam::Float64=1.0,alpha::Float64=0.5)
    out = zeros(Int64,length(nrange))
    for i in 1:length(nrange)
        out[i] = length(findAllEq(nrange[i],(nrange[i]-1)*space,delta,gam,alpha))
    end
    return out'
end


###Make tables and figures in the paper

#Table of eq types for different alpha
#maketable([0.0,0.2,0.4,0.6,0.8,1.0],501,5.0,50,251)

##Number of equilibria keeping qmax fix but increasing density of grid
##noEq([j for j in 2:10],5.0,0.75,1.0,0.75)

#Number of equilibria keeping the spacing fix, increasing qmax with number of gridpoints
noEqEqualSpace([j for j in 2:10],0.25,0.75,1.0,0.75)

#plotDeltaFinalSS(501,5.0,0.75,1.0,0.5,251,findInvestEq,"DeltaGraphInv.pdf")
#plotDeltaFinalSS(501,5.0,0.75,1.0,0.5,251,findSSEq,"DeltaGraphSS.pdf")



